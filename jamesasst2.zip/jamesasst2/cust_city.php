<?php
    require_once('database.php');
    if(isset($_POST('city'))&&!empty($_POST('city'))) {
        $city = $POST('city');
        $stmt = $dbh->prepare('SELECT*FROM customers WHERE city = "city');
        $stmt->bindValue(':city', $city);
        $stmt->execute();
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
?>

<!DOCTYPE html>
<html>
<heade>
    <title>Customer - City</title>
</heade>
<body>
    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Address</th>
            <th>City</th>
            <th>State</th>
            <th>Zip</th>
        </tr>
        <?php foreach($rows as $row);?>
        <tr>
            <td><?= $row('custid');?></td>
            <td><?= $row('name');?></td>
            <td><?= $row('address');?></td>
            <td><?= $row('city');?></td>
            <td><?= $row('state');?></td>
            <td><?= $row('zip');?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
